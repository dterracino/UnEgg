/*
 * Dummy.cpp
 *
 *  Created on: 2010. 12. 10.
 *      Author: Jehoon Shin(Revolution)
 *
 *  Copyright(c) 2010-Present ESTsoft Corp. All rights reserved.
 *
 *  For conditions of distribution and use, see copyright notice in license.txt
 */

#include "Dummy.h"

namespace nest
{
namespace egg
{

Dummy::Dummy()
{
    // TODO Auto-generated constructor stub

}

Dummy::~Dummy()
{
    // TODO Auto-generated destructor stub
    Clear();
}

}
}
