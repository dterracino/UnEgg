#ifndef AZO_X86FILTER_H
#define AZO_X86FILTER_H

#include "../Common/AZOPrivate.h"

namespace AZO {

void x86Filter(byte* buf, u_int size, bool encode);

} //namespaces AZO


#endif /*AZO_X86FILTER_H*/
